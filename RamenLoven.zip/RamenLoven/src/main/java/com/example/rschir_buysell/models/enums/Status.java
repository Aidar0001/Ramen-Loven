package com.example.rschir_buysell.models.enums;

public enum Status {
    CREATED, ACCEPTED, COOKED, DELIVERING, COMPLETED, CANCELED;
}
