package com.example.rschir_buysell.models.enums;

public enum ProductType {
    Drink, Dish
}
