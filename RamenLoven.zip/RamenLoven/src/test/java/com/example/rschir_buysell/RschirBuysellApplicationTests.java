package com.example.rschir_buysell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RschirBuysellApplicationTests {

    @Test
    void contextLoads() {
    }

}
